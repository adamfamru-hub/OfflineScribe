# Duplicutter for Windows — v1.0 Beta

**Created by PERSPICAL**  
**Developed by Adam F. Amru**

A clean, offline Windows desktop app with the Duplicutter blue–cyan design and the selected app icon.

## Features

- Scan folders (including Downloads), or all *fixed local drives*. Recursively searches documents, photos, videos, audio, archives and other files. Skips system folders and network drives.
- **Exact duplicates only**: identifies byte-identical content with file size + SHA-256. Filenames like `Adam.pdf`, `Adam (1).pdf`, and `Adam copy.pdf` can be identified as identical. Visually similar but recompressed photos are not treated as identical.
- **Protects one keeper per group**. Filename, folder, and timestamp help choose the suggested keeper. That is not proof of authorship; users should inspect the proposed keeper before cleanup.
- **Select All Extras** never selects the keeper. Even attempts to delete keeper paths directly are denied by the core engine.
- **Safe Auto Cleanup** is review-first: a preview appears and requires your confirmation. Each candidate and its keeper are re-hashed immediately before deletion. Deletions go to the **Windows Recycle Bin**, not a permanent-delete operation.
- **Move / Review** copies selected extras into a review folder, verifies the hash, records a restore journal, and then removes the source. **Restore** makes a verified copy back at the original location and never overwrites an existing file.
- Shows file size, location, date, type, original/extra status and SHA-256 when available.
- Version view recommends retaining the three latest *recognized* versions of a document family. Filename-based version inferences are informational only: older documents are **not** automatically deleted.
- Search, filter by category, sort, page through results; layout is designed for desktop windows without needing to scroll past thousands of files.

## Privacy

No account, network access, cloud upload or AI service is required. All scanning and hashing happens locally on the PC. Local settings and the review history are stored in `%LOCALAPPDATA%\Duplicutter`.

## Install / Run

Download and extract the Windows build ZIP. Run `Duplicutter.exe`. This test build is **not code-signed** with a commercial certificate; Windows SmartScreen may flag unknown downloads. Please verify the artifact source and SHA-256 and only run files you trust. No administrator rights are required for accessible user folders.

Start with a folder containing copies of expendable files, verify that the intended original is locked, then try Recycle Bin and restore. For full-drive scans, performance depends on the number and sizes of files; large scans may take minutes.

## Build

Python 3.12+; test with `python -m unittest discover -s tests -v`.

```powershell
py -3.12 -m pip install -r requirements.txt
py -3.12 app.py
```

Windows standalone binary (GitHub Actions does this automatically):

```powershell
py -3.12 -m PyInstaller --noconfirm --clean --onefile --windowed --name Duplicutter --icon assets/duplicutter.ico --add-data "assets/duplicutter.png;assets" --add-data "assets/duplicutter.ico;assets" --collect-all customtkinter --collect-all send2trash app.py
```

## Safety and limitations

- Exact hash matches guarantee equal bytes **at scan time**, not that the files have the same metadata, intended role or hidden semantic differences. If any content changes by cleanup time, deletion is refused.
- The keeper is chosen heuristically using clean filenames, original-looking folders and timestamps. No automated tool can guarantee which copy you personally consider the original.
- Windows Recycle Bin behavior depends on Windows and the storage device; certain removable and network volumes are excluded from auto scan. If Recycle Bin cannot accept a file, the operation fails without a fallback to permanent deletion.
- System files, Windows/Program Files/AppData/Recycle Bin and symlinks are excluded from full-drive scans. Administrator-only folders may be skipped.
- Files are not uploaded. If your organization restricts executable software, consult IT before installing the test build.
