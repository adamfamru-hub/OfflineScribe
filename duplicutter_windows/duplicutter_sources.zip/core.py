"""Duplicutter core: offline, conservative, byte-identical duplicate management.

No deletion occurs during scanning. Permanent deletion is not exposed: cleanup moves
verified extra copies to Windows Recycle Bin. Never trusts filenames for identity.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import tempfile
import threading
import time
import uuid
from typing import Callable, Iterable

CHUNK_SIZE = 1024 * 1024
EXTS = {
    'Photos': {'.jpg','.jpeg','.png','.heic','.heif','.webp','.gif','.bmp','.tif','.tiff','.raw','.dng','.avif','.psd','.svg'},
    'Videos': {'.mp4','.mov','.mkv','.avi','.m4v','.wmv','.flv','.webm','.3gp','.mts','.ts'},
    'Audio': {'.mp3','.wav','.flac','.m4a','.aac','.wma','.ogg','.opus','.aiff','.mid'},
    'Documents': {'.pdf','.doc','.docx','.xls','.xlsx','.ppt','.pptx','.odt','.ods','.odp','.txt','.rtf','.csv','.md','.json','.xml','.epub','.html','.htm'},
    'Archives': {'.zip','.rar','.7z','.tar','.gz','.bz2','.xz','.iso','.cab','.jar','.apk'},
}
CATEGORIES = ('Documents','Photos','Videos','Audio','Archives','Other')
SKIP_DIRS = {
    '$recycle.bin', 'system volume information', 'windows', 'program files',
    'program files (x86)', 'programdata', 'appdata', '$windows.~bt',
    '$windows.~ws', 'recovery', 'msocache', 'lost+found', '.git',
    '__pycache__', 'node_modules', '.gradle', '.thumbnails',
}


def category_of(path: str) -> str:
    suffix = Path(path).suffix.lower()
    for group, exts in EXTS.items():
        if suffix in exts:
            return group
    return 'Other'


def fingerprint(path: str, stop: threading.Event | None = None) -> str:
    sha = hashlib.sha256()
    with open(path, 'rb') as f:
        while True:
            if stop and stop.is_set():
                raise InterruptedError('Operation cancelled')
            b = f.read(CHUNK_SIZE)
            if not b:
                break
            sha.update(b)
    return sha.hexdigest()


def normalized(path: str) -> str:
    return os.path.normcase(os.path.abspath(path))


def keeper_score(path: str) -> tuple:
    """Prefer clean filename, conventional original folder, earliest mtime.

    This is a *preference*, not evidence of actual authorship/originality.
    """
    p = Path(path)
    stem = p.stem.lower()
    parent = str(p.parent).lower()
    score = 0
    if re.search(r'(?:\s|[_-])copy(?:\s?\d+)?$', stem):
        score -= 150
    if re.search(r'\s*\(\d+\)$', stem):
        score -= 180
    if re.search(r'[_\s-]\d{1,2}$', stem):
        score -= 50
    if 'original' in stem or 'master' in stem:
        score += 140
    if '\\dcim\\' in parent or '\\camera\\' in parent or '/dcim/' in parent:
        score += 50
    if 'download' in parent:
        score -= 10
    if 'copy' in parent:
        score -= 30
    try:
        mtime = p.stat().st_mtime
    except OSError:
        mtime = 0
    return (-score, mtime, normalized(path))


@dataclass(frozen=True)
class FileItem:
    path: str
    size: int
    mtime: float
    category: str

    @property
    def name(self) -> str:
        return os.path.basename(self.path)

    @property
    def directory(self) -> str:
        return os.path.dirname(self.path)


@dataclass
class DuplicateGroup:
    digest: str
    size: int
    keeper: FileItem
    extras: list[FileItem]

    @property
    def total_bytes_reclaimable(self) -> int:
        return len(self.extras) * self.size


@dataclass
class VersionFamily:
    name: str
    kept: list[FileItem]
    older: list[FileItem]


@dataclass
class ScanResult:
    files: list[FileItem] = field(default_factory=list)
    groups: list[DuplicateGroup] = field(default_factory=list)
    families: list[VersionFamily] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    duration_seconds: float = 0
    _keeper_by_extra: dict[str, DuplicateGroup] = field(default_factory=dict, repr=False)

    def rebuild_index(self) -> None:
        self._keeper_by_extra = {
            normalized(f.path): g for g in self.groups for f in g.extras
        }

    def eligible(self, path: str) -> bool:
        return normalized(path) in self._keeper_by_extra

    def group_for_extra(self, path: str) -> DuplicateGroup | None:
        return self._keeper_by_extra.get(normalized(path))

    @property
    def extras(self) -> list[FileItem]:
        return [f for group in self.groups for f in group.extras]

    @property
    def savings(self) -> int:
        return sum(g.total_bytes_reclaimable for g in self.groups)

    @property
    def indexed_bytes(self) -> int:
        return sum(f.size for f in self.files)


def is_under(path: str, root: str) -> bool:
    try:
        return os.path.commonpath([normalized(path), normalized(root)]) == normalized(root)
    except (ValueError, OSError):
        return False


def _version_identity(name: str) -> tuple[str, str, tuple] | None:
    stem = Path(name).stem.lower()
    # The same report in PDF and DOCX belongs to one version, not two revisions.
    match = re.search(r'(?<![A-Za-z0-9])(?:rev(?:ision)?|ver(?:sion)?|v)[\s._-]*(\d{1,4})(?!\d)', stem)
    date = re.search(r'(20\d{2})[-._ ]?([01]\d)[-._ ]?([0-3]\d)', stem)
    if match:
        token = match.group(0)
        kind = f'v:{int(match.group(1))}'
        rank = (3, int(match.group(1)))
        family = stem.replace(token, ' ')
    elif date:
        token = date.group(0)
        kind = f'd:{date.group(1)}{date.group(2)}{date.group(3)}'
        rank = (2, int(date.group(1)+date.group(2)+date.group(3)))
        family = stem.replace(token, ' ')
    elif re.search(r'\bfinal\b', stem):
        kind, rank = 'final', (1, 2)
        family = re.sub(r'\bfinal\b', ' ', stem)
    elif re.search(r'\bdraft\b', stem):
        kind, rank = 'draft', (1, 1)
        family = re.sub(r'\bdraft\b', ' ', stem)
    else:
        return None
    family = re.sub(r'[_().-]+', ' ', family)
    family = re.sub(r'\s+', ' ', family).strip()
    return family, kind, rank


def detect_versions(files: list[FileItem]) -> list[VersionFamily]:
    by_family: dict[tuple[str, str], dict[str, list[tuple[tuple, FileItem]]]] = defaultdict(lambda: defaultdict(list))
    for f in files:
        if f.category != 'Documents':
            continue
        lower = f.name.lower()
        if any(word in lower for word in ('signed', 'contract', 'agreement', 'executed', 'signature')):
            continue
        identity = _version_identity(f.name)
        if not identity:
            continue
        base, revision, rank = identity
        if base:
            by_family[(normalized(f.directory), base)][revision].append((rank, f))
    out: list[VersionFamily] = []
    for (folder, name), revisions in by_family.items():
        if len(revisions) <= 3:
            continue
        keys = sorted(revisions, key=lambda k: (max(x[0] for x in revisions[k]), max(x[1].mtime for x in revisions[k])), reverse=True)
        kept = [f for key in keys[:3] for _, f in revisions[key]]
        older = [f for key in keys[3:] for _, f in revisions[key]]
        out.append(VersionFamily(f'{name}   •   {os.path.basename(folder)}', kept, older))
    return sorted(out, key=lambda x: x.name)


ProgressFn = Callable[[str, int, int], None]


def scan(
    roots: Iterable[str],
    categories: Iterable[str] = CATEGORIES,
    exclude: Iterable[str] = (),
    cancel: threading.Event | None = None,
    progress: ProgressFn | None = None,
) -> ScanResult:
    """Read-only recursive scan. Exact matches MUST agree in file size and SHA-256.

    Files that change during hashing are omitted from duplicate groups.
    """
    started = time.monotonic()
    enabled = set(categories)
    skip_roots = [normalized(x) for x in exclude]
    result = ScanResult()
    visited: set[str] = set()
    errors: list[str] = []

    def report(phase: str, current: int, total: int = 0) -> None:
        if progress:
            progress(phase, current, total)

    for input_root in roots:
        if cancel and cancel.is_set():
            break
        root = os.path.abspath(os.path.expanduser(input_root))
        if not os.path.isdir(root):
            errors.append(f'Not a readable folder: {root}')
            continue

        def inaccessible(exc: OSError) -> None:
            if len(errors) < 100:
                errors.append(str(exc))

        for folder, childdirs, names in os.walk(root, onerror=inaccessible, followlinks=False):
            if cancel and cancel.is_set():
                break
            childdirs[:] = sorted(d for d in childdirs if
                d.lower() not in SKIP_DIRS and not os.path.islink(os.path.join(folder, d))
                and not any(is_under(os.path.join(folder, d), denied) for denied in skip_roots)
            )
            if any(is_under(folder, denied) for denied in skip_roots):
                childdirs.clear()
                continue
            for name in names:
                if cancel and cancel.is_set():
                    break
                path = os.path.join(folder, name)
                k = normalized(path)
                if k in visited or any(is_under(k, denied) for denied in skip_roots):
                    continue
                visited.add(k)
                category = category_of(path)
                if category not in enabled:
                    continue
                try:
                    if os.path.islink(path):
                        continue
                    st = os.stat(path)
                    if not os.path.isfile(path):
                        continue
                    result.files.append(FileItem(path, st.st_size, st.st_mtime, category))
                except OSError as e:
                    if len(errors) < 100:
                        errors.append(f'{path}: {e}')
                if len(result.files) % 800 == 0 and result.files:
                    report('Indexing', len(result.files))

    if cancel and cancel.is_set():
        result.errors = errors + ['Scan cancelled. No files changed.']
        result.duration_seconds = time.monotonic() - started
        return result

    buckets: dict[int, list[FileItem]] = defaultdict(list)
    for f in result.files:
        buckets[f.size].append(f)
    candidates = [f for group in buckets.values() if len(group) > 1 for f in group]
    report('Hashing candidates', 0, len(candidates))
    byhash: dict[tuple[int,str], list[FileItem]] = defaultdict(list)
    for i, f in enumerate(candidates, 1):
        if cancel and cancel.is_set():
            break
        try:
            before = os.stat(f.path)
            if before.st_size != f.size or before.st_mtime_ns != int(f.mtime * 1_000_000_000):
                # Accurate float roundtrips can differ; compare within 2 microseconds.
                if before.st_size != f.size or abs(before.st_mtime - f.mtime) > 0.000002:
                    continue
            digest = fingerprint(f.path, cancel)
            after = os.stat(f.path)
            if after.st_size != f.size or abs(after.st_mtime - f.mtime) > 0.000002:
                continue
            byhash[(f.size, digest)].append(f)
        except (OSError, InterruptedError) as e:
            if len(errors) < 100:
                errors.append(f'Cannot hash {f.path}: {e}')
        if i % 12 == 0 or i == len(candidates):
            report('Hashing candidates', i, len(candidates))

    if not (cancel and cancel.is_set()):
        for (size,digest), items in byhash.items():
            if len(items) < 2:
                continue
            sorted_items = sorted(items, key=lambda f: keeper_score(f.path))
            result.groups.append(DuplicateGroup(digest, size, sorted_items[0], sorted_items[1:]))
        result.groups.sort(key=lambda g: (g.total_bytes_reclaimable, len(g.extras)), reverse=True)
        result.families = detect_versions(result.files)
        result.rebuild_index()
    else:
        errors.append('Scan cancelled. No files changed.')
    result.errors = errors
    result.duration_seconds = time.monotonic() - started
    report('Done', len(result.files), len(result.files))
    return result


class SafetyError(RuntimeError):
    pass


def validate_extra(result: ScanResult, path: str, stop: threading.Event | None = None) -> DuplicateGroup:
    """Deny-by-default guard used immediately BEFORE each deletion/move."""
    group = result.group_for_extra(path)
    if group is None:
        raise SafetyError('Not an eligible extra copy; the original is protected.')
    if normalized(path) == normalized(group.keeper.path):
        raise SafetyError('Protected original cannot be removed.')
    if not os.path.isfile(group.keeper.path):
        raise SafetyError('The protected original is missing.')
    if not os.path.isfile(path):
        raise SafetyError('Candidate file is missing.')
    for candidate in (path, group.keeper.path):
        if stop and stop.is_set():
            raise InterruptedError('Cancelled')
        st = os.stat(candidate)
        if st.st_size != group.size or fingerprint(candidate, stop) != group.digest:
            raise SafetyError(f'File changed since scan; refusing cleanup: {candidate}')
    return group


def recycle_extras(result: ScanResult, paths: Iterable[str],
                   stop: threading.Event | None = None,
                   progress: Callable[[int,int,str],None] | None = None) -> tuple[list[str], list[str]]:
    from send2trash import send2trash
    unique = list(dict.fromkeys(os.path.abspath(p) for p in paths))
    complete, errors = [], []
    for i, path in enumerate(unique, 1):
        if stop and stop.is_set():
            errors.append('Cancelled by user.')
            break
        try:
            validate_extra(result, path, stop)
            send2trash(path)  # Windows Recycle Bin, not unlink/permanent deletion.
            complete.append(path)
        except (OSError, SafetyError, InterruptedError, Exception) as e:
            errors.append(f'{os.path.basename(path)}: {e}')
        if progress:
            progress(i, len(unique), os.path.basename(path))
    return complete, errors


class ReviewJournal:
    def __init__(self, destination: str, data_dir: str | None = None):
        self.destination = os.path.abspath(destination)
        self.data_dir = Path(data_dir or os.path.join(os.environ.get('LOCALAPPDATA',str(Path.home())), 'Duplicutter'))
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.journal = self.data_dir / 'review_history.json'
        self._lock = threading.RLock()

    def records(self) -> list[dict]:
        with self._lock:
            try:
                return json.loads(self.journal.read_text('utf-8'))
            except (FileNotFoundError, json.JSONDecodeError, OSError):
                return []

    def _write(self, rows: list[dict]) -> None:
        tmp = self.journal.with_name(f'{self.journal.name}.{uuid.uuid4().hex}.tmp')
        try:
            with open(tmp, 'w', encoding='utf-8') as output:
                json.dump(rows, output, indent=2, ensure_ascii=False)
                output.flush()
                os.fsync(output.fileno())
            os.replace(tmp, self.journal)
        finally:
            if tmp.exists():
                tmp.unlink()

    def _add(self, item: dict) -> None:
        with self._lock:
            rows = self.records()
            rows.insert(0, item)
            self._write(rows)

    def _update(self, identifier: str, state: str) -> None:
        with self._lock:
            rows = self.records()
            for entry in rows:
                if entry.get('id') == identifier:
                    entry['status'] = state
                    entry['updated_utc'] = datetime.now(timezone.utc).isoformat()
            self._write(rows)

    def set_aside(self, result: ScanResult, path: str, *, category_subfolders: bool = True) -> dict:
        group = validate_extra(result, path)
        if is_under(path, self.destination):
            raise SafetyError('Source is already inside the review folder.')
        destination = Path(self.destination) / (category_of(path) if category_subfolders else '')
        destination.mkdir(parents=True, exist_ok=True)
        name = f'{uuid.uuid4().hex[:10]}_{Path(path).name}'
        target = destination / name
        temporary = destination / (name + '.copying')
        try:
            with open(path,'rb') as inp, open(temporary,'xb') as out:
                shutil.copyfileobj(inp,out, CHUNK_SIZE)
                out.flush()
                os.fsync(out.fileno())
            if fingerprint(str(temporary)) != group.digest:
                raise SafetyError('Review copy failed checksum verification. Original retained.')
            os.replace(temporary, target)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        item = {
            'id': uuid.uuid4().hex,
            'source': path,
            'review': str(target),
            'digest': group.digest,
            'size': group.size,
            'status': 'copied_pending_source_removal',
            'created_utc': datetime.now(timezone.utc).isoformat(),
        }
        self._add(item) # Commit journal BEFORE the source is removed.
        try:
            os.unlink(path)
            self._update(item['id'], 'in_review')
        except Exception as e:
            self._update(item['id'], 'original_retained')
            raise SafetyError(f'Original not removed; verified review copy retained at {target}: {e}')
        return item

    def restore(self, identifier: str) -> str:
        items = self.records()
        item = next((r for r in items if r.get('id') == identifier), None)
        if item is None:
            raise FileNotFoundError('Review history record not found')
        review = Path(item['review'])
        if not review.is_file():
            raise FileNotFoundError('Review copy was not found')
        if fingerprint(str(review)) != item['digest']:
            raise SafetyError('Review copy contents changed; restore refused')
        original = Path(item['source'])
        if not original.parent.exists():
            raise FileNotFoundError('Original folder is missing; no automatic folder creation')
        if original.exists():
            name = f'{original.stem}_RESTORED_{datetime.now().strftime("%Y%m%d_%H%M%S")}{original.suffix}'
            original = original.with_name(name)
        temp = original.with_name(f'{original.name}.{uuid.uuid4().hex[:8]}.restoring')
        try:
            with open(review,'rb') as inp, open(temp,'xb') as out:
                shutil.copyfileobj(inp,out, CHUNK_SIZE)
                out.flush()
                os.fsync(out.fileno())
            if fingerprint(str(temp)) != item['digest']:
                raise SafetyError('Restore checksum failed; review copy retained')
            os.replace(temp, original)
        finally:
            temp.unlink(missing_ok=True)
        # If review cleanup fails, original still safely restored.
        self._update(item['id'], 'restored')
        try:
            review.unlink()
        except OSError:
            self._update(item['id'], 'restored_review_copy_retained')
        return str(original)


def fixed_local_drives() -> list[str]:
    """Return local fixed Windows drive roots only, excluding network/USB drives."""
    if os.name != 'nt':
        return []
    import ctypes
    kernel = ctypes.windll.kernel32
    mask = kernel.GetLogicalDrives()
    out = []
    for i in range(26):
        if mask & (1 << i):
            drive = f'{chr(65+i)}:\\'
            if kernel.GetDriveTypeW(ctypes.c_wchar_p(drive)) == 3:  # DRIVE_FIXED
                out.append(drive)
    return out


def human_size(value: int) -> str:
    quantity = float(value)
    for unit in ('B','KB','MB','GB','TB'):
        if quantity < 1024 or unit == 'TB':
            return f'{quantity:,.0f} {unit}' if unit == 'B' else f'{quantity:,.1f} {unit}'
        quantity /= 1024
    return ''
