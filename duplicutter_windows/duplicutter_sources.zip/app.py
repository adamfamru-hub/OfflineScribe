"""Duplicutter Windows desktop app • native Python / CustomTkinter UI.

Created by PERSPICAL. Developed by Adam F. Amru.
Safety: delete only SHA-256-verified extra copies, always into Windows Recycle Bin.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time
import traceback
from typing import Callable

import customtkinter as ctk
from PIL import Image
from tkinter import filedialog

from core import (
    CATEGORIES, FileItem, ScanResult, ReviewJournal, SafetyError,
    fixed_local_drives, human_size, fingerprint, normalized,
    recycle_extras, scan,
)

ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('blue')

NAVY = '#061431'
BACK = '#071B42'
PANEL = '#0C2A62'
PANEL2 = '#103675'
EDGE = '#2365B2'
CYAN = '#46DAF9'
AQUA = '#9BF2FF'
LIGHT = '#F2F9FF'
MUTED = '#B0CEEF'
FAINT = '#779DCC'
RED = '#D93365'
GREEN = '#53E0C4'
BUTTON = '#1468F5'
BTN_HOVER = '#258FEB'

DATA_DIR = Path(os.environ.get('LOCALAPPDATA') or str(Path.home())) / 'Duplicutter'
CONFIG_FILE = DATA_DIR / 'settings.json'
ROOT_DIR = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
IMAGE_FILE = ROOT_DIR / 'assets' / 'duplicutter.png'


def read_settings() -> dict:
    try:
        value = json.loads(CONFIG_FILE.read_text('utf-8'))
        if isinstance(value,dict):
            return value
    except (OSError, ValueError):
        pass
    return {}


def write_settings(data: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    staging = CONFIG_FILE.with_suffix('.tmp')
    staging.write_text(json.dumps(data, indent=2), 'utf-8')
    os.replace(staging, CONFIG_FILE)


def active_folder(path: str) -> bool:
    return os.path.isdir(path)


def make_text(parent, text, size=13, color=LIGHT, weight='normal', **opts):
    return ctk.CTkLabel(parent, text=text, text_color=color, font=ctk.CTkFont(family='Segoe UI',size=size,weight=weight), **opts)


def ui_button(parent, text, command, variant='primary', width=130, height=40):
    colors = {
        'primary': (BUTTON,BTN_HOVER),
        'secondary': (PANEL2,'#1854A1'),
        'outline': (PANEL,'#144380'),
        'danger': (RED,'#AC2150'),
        'cyan': ('#0CAEDB','#098BC8'),
    }
    main, hover = colors[variant]
    return ctk.CTkButton(parent,text=text, command=command, width=width,height=height,
        fg_color=main,hover_color=hover,corner_radius=13,
        border_width=1,border_color=CYAN if variant in ('primary','cyan') else EDGE,
        text_color=LIGHT,font=ctk.CTkFont(family='Segoe UI',size=12,weight='bold'))


class Duplicutter(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title('Duplicutter — Smart Duplicate Finder & Cleanup')
        self.geometry('1250x795')
        self.minsize(950,640)
        self.configure(fg_color=NAVY)
        try:
            self.iconbitmap(str(ROOT_DIR / 'assets' / 'duplicutter.ico'))
        except Exception:
            pass
        self.settings = read_settings()
        self.paths: list[str] = [p for p in self.settings.get('folders', []) if active_folder(p)]
        self.types: set[str] = set(self.settings.get('types', CATEGORIES))
        if not self.types:
            self.types = set(CATEGORIES)
        self.review_root = self.settings.get('review_folder', str(Path.home() / 'Documents' / 'Duplicutter_Review'))
        self.results: ScanResult | None = None
        self.selected: set[str] = set()
        self.view = 'Overview'
        self.query = ''
        self.category_filter = 'All'
        self.sort_filter = 'Largest savings'
        self.page = 0
        self.page_size = 28
        self.rows = []
        self.cancel_event = threading.Event()
        self.queue: queue.Queue = queue.Queue()
        self.busy = False
        self._popup = None
        self.ico = None
        try:
            image = Image.open(IMAGE_FILE)
            self.ico = ctk.CTkImage(light_image=image,dark_image=image,size=(57,57))
        except Exception:
            pass
        self._build_shell()
        self._navigate('Overview')
        self.after(120,self._drain_queue)
        self.protocol('WM_DELETE_WINDOW',self._exit)

    def _save(self):
        self.settings.update({'folders':self.paths,'types':sorted(self.types),'review_folder':self.review_root})
        try:
            write_settings(self.settings)
        except OSError as e:
            self._status(f'Could not save preferences: {e}')

    def _build_shell(self):
        self.grid_columnconfigure(1,weight=1)
        self.grid_rowconfigure(1,weight=1)
        top=ctk.CTkFrame(self,fg_color='#081D47',corner_radius=0,height=86)
        top.grid(row=0,column=0,columnspan=2,sticky='ew')
        top.grid_propagate(False)
        if self.ico:
            ctk.CTkLabel(top,text='',image=self.ico).pack(side='left',padx=(20,13),pady=10)
        title_stack=ctk.CTkFrame(top,fg_color='transparent')
        title_stack.pack(side='left',padx=8,pady=13)
        make_text(title_stack,'Duplicutter',27,LIGHT,'bold').pack(anchor='w')
        make_text(title_stack,'Find. Remove. Free up space.',12,MUTED).pack(anchor='w')
        make_text(top,'Created by PERSPICAL   •   Developed by Adam F. Amru',11,FAINT).pack(side='right',padx=26)
        self.sidebar=ctk.CTkFrame(self,fg_color='#061637',corner_radius=0,width=224)
        self.sidebar.grid(row=1,column=0,sticky='nsw')
        self.sidebar.grid_propagate(False)
        make_text(self.sidebar,'WORKSPACE',11,FAINT,'bold').pack(anchor='w',padx=23,pady=(30,10))
        self.nav_buttons={}
        for label, glyph in [('Overview','▦'),('Exact Duplicates','▣'),('Report Versions','▤'),('All Files','▧'),('Manual Review','↶')]:
            b=ui_button(self.sidebar, f'{glyph}  {label}',lambda v=label:self._navigate(v),variant='outline',width=183,height=45)
            b.pack(pady=5,padx=20)
            self.nav_buttons[label]=b
        ctk.CTkFrame(self.sidebar,fg_color=EDGE,height=1).pack(fill='x',padx=18,pady=22)
        ui_button(self.sidebar,'+  Add Folder',self._add_folder,'secondary',width=183).pack(padx=20,pady=5)
        ui_button(self.sidebar,'Scan Folders',self._scan_folders,'primary',width=183).pack(padx=20,pady=5)
        ui_button(self.sidebar,'Scan Local Drives',self._scan_drives,'cyan',width=183).pack(padx=20,pady=5)
        self.status=make_text(self.sidebar,'Ready • Nothing deleted automatically',11,MUTED,wraplength=182,justify='left')
        self.status.pack(side='bottom',anchor='w',padx=20,pady=20)
        self.body=ctk.CTkFrame(self,fg_color=BACK,corner_radius=0)
        self.body.grid(row=1,column=1,sticky='nsew')
        self.body.grid_columnconfigure(0,weight=1)
        self.body.grid_rowconfigure(1,weight=1)
        self.head=ctk.CTkFrame(self.body,fg_color='transparent')
        self.head.grid(row=0,column=0,sticky='ew',padx=23,pady=(19,9))
        self.content=ctk.CTkFrame(self.body,fg_color='transparent')
        self.content.grid(row=1,column=0,sticky='nsew',padx=(17,21),pady=(0,6))
        self.content.grid_columnconfigure(0,weight=1)
        self.content.grid_rowconfigure(0,weight=1)
        self.footer=ctk.CTkFrame(self.body,fg_color=PANEL,corner_radius=15,border_width=1,border_color=EDGE,height=60)
        self.footer.grid(row=2,column=0,sticky='ew',padx=22,pady=(4,15))
        self.footer.grid_propagate(False)

    def _clear(self, frame):
        for w in frame.winfo_children():
            w.destroy()

    def _status(self, msg: str):
        self.status.configure(text=msg[:240])

    def _heading(self,title:str,description:str):
        self._clear(self.head)
        make_text(self.head,title,25,LIGHT,'bold').pack(anchor='w')
        make_text(self.head,description,12,MUTED).pack(anchor='w',pady=(5,0))

    def _navigate(self, label: str):
        if self.busy and label not in ('Overview','Exact Duplicates'):
            return
        self.view=label
        self.page=0
        for title,button in self.nav_buttons.items():
            button.configure(fg_color=BUTTON if title==label else PANEL, border_color=CYAN if title==label else EDGE)
        self._render()

    def _render(self):
        self._clear(self.content)
        self._clear(self.footer)
        self.content.grid_rowconfigure(0,weight=1)
        self.content.grid_rowconfigure(1,weight=0)
        if self.view == 'Overview':
            self._overview()
        elif self.view == 'Exact Duplicates':
            self._duplicates()
        elif self.view == 'Report Versions':
            self._versions()
        elif self.view == 'All Files':
            self._all_files()
        else:
            self._review()

    def _panel(self,parent,header,sub=None):
        box=ctk.CTkFrame(parent,fg_color=PANEL,corner_radius=18,border_width=1,border_color=EDGE)
        make_text(box,header,18,LIGHT,'bold').pack(anchor='w',padx=18,pady=(14,1))
        if sub:
            make_text(box,sub,11,MUTED).pack(anchor='w',padx=18,pady=(0,9))
        return box

    def _overview(self):
        self._heading('Storage Overview','Fast, private file cleanup. Every deletion requires your approval.')
        scroll=ctk.CTkScrollableFrame(self.content,fg_color='transparent',corner_radius=0)
        scroll.grid(row=0,column=0,sticky='nsew')
        scroll.grid_columnconfigure((0,1),weight=1)
        stats=ctk.CTkFrame(scroll,fg_color='transparent')
        stats.grid(row=0,column=0,columnspan=2,sticky='ew',pady=(0,15))
        stats.grid_columnconfigure((0,1,2,3),weight=1)
        res=self.results
        values=[('Files Indexed',str(len(res.files)) if res else '—'),
                ('Duplicate Groups',str(len(res.groups)) if res else '—'),
                ('Potential Savings',human_size(res.savings) if res else '—'),
                ('Extra Copies',str(len(res.extras)) if res else '—')]
        for i,(name,value) in enumerate(values):
            cell=ctk.CTkFrame(stats,fg_color=PANEL2,corner_radius=15,border_width=1,border_color=EDGE)
            cell.grid(row=0,column=i,sticky='ew',padx=5)
            make_text(cell,value,25,AQUA,'bold').pack(pady=(14,0))
            make_text(cell,name,11,MUTED).pack(pady=(4,15))

        sources=self._panel(scroll,'Source Folders','Selected folders are scanned recursively, including Downloads when permitted.')
        sources.grid(row=1,column=0,sticky='nsew',padx=(4,7),pady=(0,12))
        rows=ctk.CTkFrame(sources,fg_color='transparent');rows.pack(fill='x',padx=14)
        if self.paths:
            for path in self.paths[:7]:
                line=ctk.CTkFrame(rows,fg_color=PANEL2,corner_radius=9)
                line.pack(fill='x',pady=3)
                make_text(line,'▣  '+self._shorten(path,64),11,LIGHT,anchor='w').pack(side='left',fill='x',expand=True,padx=10,pady=8)
                ui_button(line,'×',lambda p=path:self._remove_folder(p),'secondary',width=32,height=30).pack(side='right',padx=4)
            if len(self.paths)>7:
                make_text(rows,f'+ {len(self.paths)-7} more source folders',11,FAINT).pack(anchor='w')
        else:
            make_text(rows,'No source folders added yet.',12,MUTED).pack(anchor='w',pady=12)
        bar=ctk.CTkFrame(sources,fg_color='transparent');bar.pack(fill='x',padx=14,pady=12)
        ui_button(bar,'+ Add Source',self._add_folder,'primary',width=120).pack(side='left',padx=(0,7))
        ui_button(bar,'Scan Folders',self._scan_folders,'secondary',width=125).pack(side='left')

        types=self._panel(scroll,'File Types','Include or exclude categories before scanning.')
        types.grid(row=1,column=1,sticky='nsew',padx=(7,4),pady=(0,12))
        grid=ctk.CTkFrame(types,fg_color='transparent');grid.pack(fill='x',padx=17,pady=(4,13))
        for i,category in enumerate(CATEGORIES):
            flag=ctk.BooleanVar(value=category in self.types)
            def change(cat=category,variable=flag):
                if variable.get():self.types.add(cat)
                else:self.types.discard(cat)
                self._save()
            widget=ctk.CTkCheckBox(grid,text=category,variable=flag,command=change,
                fg_color=BUTTON,hover_color=BTN_HOVER,checkmark_color='white',
                text_color=LIGHT,border_color=CYAN,font=ctk.CTkFont(size=12))
            widget.grid(row=i//2,column=i%2,sticky='w',padx=(0,23),pady=11)

        actions=self._panel(scroll,'Quick Actions','Safe cleanup keeps one protected copy in every SHA-256 group.')
        actions.grid(row=2,column=0,sticky='nsew',padx=(4,7),pady=(0,12))
        ui_button(actions,'⌕  SCAN ALL LOCAL DRIVES',self._scan_drives,'cyan',height=45).pack(fill='x',padx=17,pady=(2,7))
        ui_button(actions,'SELECT ALL EXTRAS',self._select_all_extras,'secondary',height=45).pack(fill='x',padx=17,pady=6)
        ui_button(actions,'SAFE AUTO CLEANUP',self._auto_cleanup,'primary',height=45).pack(fill='x',padx=17,pady=(6,16))

        review=self._panel(scroll,'Manual Review Folder','You can move verified extras here and restore them later.')
        review.grid(row=2,column=1,sticky='nsew',padx=(7,4),pady=(0,12))
        make_text(review,self._shorten(self.review_root,70),11,MUTED,wraplength=365,justify='left').pack(anchor='w',padx=17,pady=10)
        ui_button(review,'Choose Review Folder',self._choose_review,'secondary').pack(fill='x',padx=17,pady=(3,8))
        ui_button(review,'Open Review History',lambda:self._navigate('Manual Review'),'primary').pack(fill='x',padx=17,pady=(0,15))
        if res and res.errors:
            issue=self._panel(scroll,'Scan Notes',f'{len(res.errors)} skipped or unreadable files/folders')
            issue.grid(row=3,column=0,columnspan=2,sticky='ew',padx=4,pady=(0,8))
            make_text(issue,res.errors[0][:140],11,MUTED,wraplength=800).pack(anchor='w',padx=18,pady=10)
        self._footer_note('NO AUTO-DELETION  •  SHA-256 CONTENT MATCH  •  WINDOWS RECYCLE BIN')

    def _shorten(self, text: str, maxchars=70) -> str:
        if len(text)<=maxchars:return text
        return text[:16]+' … '+text[-maxchars+20:]

    def _footer_note(self,message:str):
        make_text(self.footer,message,12,MUTED,'bold').pack(side='left',padx=18,pady=17)

    def _add_folder(self):
        folder=filedialog.askdirectory(parent=self,title='Choose folder to scan')
        if folder and normalized(folder) not in {normalized(p) for p in self.paths}:
            self.paths.append(folder)
            self._save();self._render()

    def _remove_folder(self,path:str):
        self.paths=[p for p in self.paths if normalized(p)!=normalized(path)]
        self._save();self._render()

    def _choose_review(self):
        folder=filedialog.askdirectory(parent=self,title='Choose a Manual Review destination')
        if folder:
            self.review_root=folder
            self._save();self._render()

    def _scan_folders(self):
        if not self.paths:
            self._info('No source folders','Choose at least one source folder first.')
            return
        self._start_scan(self.paths)

    def _scan_drives(self):
        drives=fixed_local_drives()
        if not drives:
            self._info('Drives unavailable','Could not locate any fixed local Windows drive. Select folders manually.')
            return
        self._confirm('Scan all local drives?',
            'The app will index local fixed drives: '+', '.join(drives)+'.\n\nSystem folders (Windows, Program Files, AppData, Recycle Bin) will be skipped. Network drives are not included. The scan may take minutes on large drives. No files are changed.',
            lambda:self._start_scan(drives),action='START SCAN',tone='primary')

    def _start_scan(self,folders:list[str]):
        if self.busy:return
        if not self.types:
            self._info('No file types','Select at least one file category on Overview.')
            return
        self.busy=True;self.cancel_event.clear()
        self._status('Scanning • please wait…')
        self._navigate('Exact Duplicates')
        self._status('Scanning, all actions disabled…')
        def report(phase,n,total):
            self.queue.put(('progress',(phase,n,total)))
        def job():
            try:
                found=scan(folders,self.types,exclude=[self.review_root],cancel=self.cancel_event,progress=report)
                self.queue.put(('scan_complete',found))
            except Exception as e:
                self.queue.put(('error',f'Scan failed: {e}'))
        threading.Thread(target=job,name='DuplicutterScanner',daemon=True).start()

    def _controls(self,title,description,with_sort=True):
        self._heading(title,description)
        bar=ctk.CTkFrame(self.content,fg_color='transparent')
        bar.grid(row=0,column=0,sticky='ew',pady=(1,6))
        bar.grid_columnconfigure(0,weight=1)
        self.search=ctk.CTkEntry(bar,placeholder_text='⌕  Search filenames or folders…',height=42,
            fg_color=PANEL,border_color=EDGE,text_color=LIGHT,placeholder_text_color=FAINT,corner_radius=13)
        self.search.grid(row=0,column=0,sticky='ew',padx=(5,8))
        self.search.insert(0,self.query)
        self.search.bind('<KeyRelease>',lambda e:self._search_changed())
        self.filterbox=ctk.CTkOptionMenu(bar,values=['All',*CATEGORIES],width=134,height=42,
            fg_color=PANEL2,button_color=EDGE,button_hover_color=BUTTON,
            dropdown_fg_color=PANEL2,text_color=LIGHT,command=self._set_filter)
        self.filterbox.set(self.category_filter);self.filterbox.grid(row=0,column=1,padx=(0,7))
        if with_sort:
            self.orderbox=ctk.CTkOptionMenu(bar,values=['Largest savings','Newest','Name'],width=154,height=42,
                fg_color=PANEL2,button_color=EDGE,dropdown_fg_color=PANEL2,text_color=LIGHT,
                command=self._set_sort)
            self.orderbox.set(self.sort_filter);self.orderbox.grid(row=0,column=2,padx=(0,5))
        frame=ctk.CTkScrollableFrame(self.content,fg_color='transparent')
        frame.grid(row=1,column=0,sticky='nsew')
        self.content.grid_rowconfigure(1,weight=1)
        self.content.grid_rowconfigure(0,weight=0)
        self.list_content=frame

    def _search_changed(self):
        self.query=self.search.get().strip().casefold()
        self.page=0;self._populate()

    def _set_filter(self,value):
        self.category_filter=value;self.page=0;self._populate()

    def _set_sort(self,value):
        self.sort_filter=value;self.page=0;self._populate()

    def _duplicates(self):
        self._controls('Exact Duplicate Finder','Byte-identical content, verified using SHA-256. Originals are locked.')
        self._populate()
        self._action_footer(duplicates=True)

    def _versions(self):
        self._controls('Report Versions','Keep latest 3 recognized revision groups. Older reports require manual review.',with_sort=False)
        self._populate()
        self._footer_note('OLDER VERSIONS ARE NOT AUTOMATICALLY DELETED. EXACT DUPLICATES ONLY.')

    def _all_files(self):
        self._controls('All Scanned Files','Explore all indexed files. Double-click Details for size, path, and timestamps.')
        self._populate()
        self._footer_note('ALL FILES IS VIEW-ONLY • ONLY VERIFIED EXTRA COPIES CAN BE DELETED')

    def _populate(self):
        if self.view not in ('Exact Duplicates','Report Versions','All Files'):
            return
        frame=getattr(self,'list_content',None)
        if not frame or not frame.winfo_exists():
            return
        self._clear(frame)
        res=self.results
        if not res:
            make_text(frame,'No scan results yet.',20,LIGHT,'bold').pack(anchor='w',padx=24,pady=(35,5))
            make_text(frame,'Add a source folder or choose Scan Local Drives from the left.',13,MUTED).pack(anchor='w',padx=24)
            return
        if self.view=='Exact Duplicates':
            self._render_duplicate_rows(frame,res)
        elif self.view=='Report Versions':
            self._render_versions(frame,res)
        else:
            self._render_files(frame,res)

    def _paginate(self,items,per_page=None):
        size=per_page or self.page_size
        pages=max(1,(len(items)+size-1)//size)
        self.page=min(self.page,pages-1)
        start=self.page*size
        return items[start:start+size],pages

    def _row_card(self,parent):
        row=ctk.CTkFrame(parent,fg_color=PANEL,corner_radius=14,border_color=EDGE,border_width=1)
        row.pack(fill='x',padx=6,pady=4)
        return row

    def _render_duplicate_rows(self,frame,res):
        groups=[]
        for group in res.groups:
            choices=[group.keeper,*group.extras]
            if self.category_filter != 'All' and not any(f.category==self.category_filter for f in choices):
                continue
            if self.query and not any(self.query in f.path.casefold() for f in choices):
                continue
            groups.append(group)
        if self.sort_filter=='Newest':
            groups.sort(key=lambda g:max(f.mtime for f in [g.keeper,*g.extras]),reverse=True)
        elif self.sort_filter=='Name':
            groups.sort(key=lambda g:g.keeper.name.casefold())
        else:
            groups.sort(key=lambda g:g.total_bytes_reclaimable,reverse=True)
        page_items,pages=self._paginate(groups,6)
        self._update_pager(pages,len(groups),'groups')
        if not page_items:
            make_text(frame,'No matching duplicate groups.',18,MUTED).pack(anchor='w',padx=22,pady=26)
            return
        for group in page_items:
            card=self._row_card(frame)
            head=ctk.CTkFrame(card,fg_color=PANEL2,corner_radius=12)
            head.pack(fill='x',padx=8,pady=(8,6))
            make_text(head,f'▣   IDENTICAL CONTENT   •   {len(group.extras)+1} files',14,LIGHT,'bold').pack(side='left',padx=11,pady=9)
            make_text(head,human_size(group.total_bytes_reclaimable)+' potential saving',12,AQUA,'bold').pack(side='right',padx=12)
            self._duplicate_row(card,group.keeper,locked=True)
            for f in group.extras:
                self._duplicate_row(card,f,locked=False)

    def _duplicate_row(self,parent,f:FileItem,locked:bool):
        line=ctk.CTkFrame(parent,fg_color='#0A214E' if locked else '#134180',corner_radius=11)
        line.pack(fill='x',padx=9,pady=3)
        if locked:
            make_text(line,'🔒',14,GREEN).pack(side='left',padx=(12,5))
        else:
            variable=ctk.BooleanVar(value=normalized(f.path) in self.selected)
            def click(p=f.path,flag=variable):
                if flag.get():self.selected.add(normalized(p))
                else:self.selected.discard(normalized(p))
                self._refresh_selected_text()
            box=ctk.CTkCheckBox(line,text='',variable=variable,command=click,
                fg_color=BUTTON,checkmark_color='white',border_color=CYAN,width=28)
            box.pack(side='left',padx=(12,1),pady=9)
        text=ctk.CTkFrame(line,fg_color='transparent')
        text.pack(side='left',fill='x',expand=True,padx=7,pady=5)
        make_text(text,('KEEP ORIGINAL   •   ' if locked else 'EXTRA COPY   •   ')+self._shorten(f.name,67),12,
            GREEN if locked else LIGHT,'bold').pack(anchor='w')
        make_text(text,self._shorten(f.directory,88)+'   •   '+human_size(f.size),10,MUTED).pack(anchor='w',pady=1)
        ui_button(line,'Details',lambda x=f:self._details(x,locked),'secondary',width=76,height=33).pack(side='right',padx=9)

    def _render_versions(self,frame,res):
        if not res.families:
            make_text(frame,'No report families with more than three recognized revisions.',15,MUTED).pack(padx=22,pady=24)
            return
        families=[v for v in res.families if not self.query or self.query in v.name.casefold()
            or any(self.query in f.name.casefold() for f in [*v.kept,*v.older])]
        page_items,pages=self._paginate(families,7)
        self._update_pager(pages,len(families),'families')
        for fam in page_items:
            p=self._row_card(frame)
            make_text(p,'▤   '+fam.name,14,LIGHT,'bold').pack(anchor='w',padx=13,pady=(10,5))
            make_text(p,f'{len(fam.kept)} files in latest 3 revisions • {len(fam.older)} older files to review',11,MUTED).pack(anchor='w',padx=13)
            for f in fam.kept[:6]:
                make_text(p,'  KEEP   '+self._shorten(f.name,90),11,GREEN).pack(anchor='w',padx=13,pady=2)
            for f in fam.older[:8]:
                bar=ctk.CTkFrame(p,fg_color=PANEL2,corner_radius=8)
                bar.pack(fill='x',padx=12,pady=2)
                make_text(bar,'REVIEW   '+self._shorten(f.name,66)+' • '+human_size(f.size),11,LIGHT).pack(side='left',padx=8,pady=5)
                ui_button(bar,'Details',lambda x=f:self._details(x,False),'secondary',width=68,height=29).pack(side='right',padx=5)
            make_text(p,'Older versions are informational; no bulk delete available.',10,FAINT).pack(anchor='w',padx=13,pady=(3,10))

    def _render_files(self,frame,res):
        rows=[f for f in res.files if (self.category_filter=='All' or f.category==self.category_filter)
              and (not self.query or self.query in f.path.casefold())]
        if self.sort_filter=='Newest':rows.sort(key=lambda f:f.mtime,reverse=True)
        elif self.sort_filter=='Name':rows.sort(key=lambda f:f.name.lower())
        else:rows.sort(key=lambda f:f.size,reverse=True)
        page_items,pages=self._paginate(rows,35)
        self._update_pager(pages,len(rows),'files')
        for f in page_items:
            row=self._row_card(frame)
            tag='PROTECTED ORIGINAL' if any(normalized(f.path)==normalized(g.keeper.path) for g in res.groups) else ('EXTRA COPY' if res.eligible(f.path) else f.category.upper())
            make_text(row,self._shorten(f.name,85),12,LIGHT,'bold').pack(anchor='w',padx=12,pady=(7,1))
            line=ctk.CTkFrame(row,fg_color='transparent');line.pack(fill='x',padx=12,pady=(0,7))
            make_text(line,self._shorten(f.directory,76)+'   •   '+human_size(f.size)+'  •   '+tag,11,
                GREEN if tag=='PROTECTED ORIGINAL' else MUTED).pack(side='left',fill='x',expand=True)
            ui_button(line,'Details',lambda x=f:self._details(x,not res.eligible(x.path)),'secondary',width=75,height=30).pack(side='right')

    def _update_pager(self,pages,count,label):
        self._pager_pages=pages
        # Fixed action footer has compact page buttons; for version/files views add a small bar under results.
        if self.view!='Exact Duplicates':
            bar=ctk.CTkFrame(self.list_content,fg_color='transparent')
            bar.pack(fill='x',pady=(7,5))
            ui_button(bar,'◀ Previous',lambda:self._move_page(-1),'secondary',width=112).pack(side='left',padx=7)
            make_text(bar,f'Page {self.page+1} / {pages}   •   {count} {label}',11,MUTED).pack(side='left',expand=True)
            ui_button(bar,'Next ▶',lambda:self._move_page(1),'secondary',width=112).pack(side='right',padx=7)
        else:
            if hasattr(self,'page_text') and self.page_text.winfo_exists():
                self.page_text.configure(text=f'Page {self.page+1}/{pages}   •   {count} groups')

    def _move_page(self,offset):
        self.page=max(0,min(getattr(self,'_pager_pages',1)-1,self.page+offset))
        self._populate()
        if hasattr(self,'list_content'):
            try:self.list_content._parent_canvas.yview_moveto(0)
            except Exception:pass

    def _action_footer(self,duplicates=True):
        if not duplicates:return
        self.selected_text=make_text(self.footer,'0 selected',12,MUTED,'bold')
        self.selected_text.pack(side='left',padx=(14,10))
        ui_button(self.footer,'SELECT ALL EXTRAS',self._select_all_extras,'primary',width=152,height=38).pack(side='left',padx=4)
        ui_button(self.footer,'CLEAR',self._clear_selection,'secondary',width=67,height=38).pack(side='left',padx=4)
        ui_button(self.footer,'TO RECYCLE BIN',self._delete_selected,'danger',width=130,height=38).pack(side='right',padx=(5,12))
        ui_button(self.footer,'MOVE / REVIEW',self._review_selected,'cyan',width=124,height=38).pack(side='right',padx=4)
        nav=ctk.CTkFrame(self.footer,fg_color='transparent')
        nav.pack(side='right',padx=5)
        ui_button(nav,'‹',lambda:self._move_page(-1),'secondary',width=30,height=30).pack(side='left',padx=1)
        self.page_text=make_text(nav,'Page —',10,MUTED)
        self.page_text.pack(side='left',padx=5)
        ui_button(nav,'›',lambda:self._move_page(1),'secondary',width=30,height=30).pack(side='left',padx=1)
        self._refresh_selected_text()
        if self.results:
            self._update_pager(getattr(self,'_pager_pages',1),len(self.results.groups),'groups')

    def _refresh_selected_text(self):
        if hasattr(self,'selected_text') and self.selected_text.winfo_exists():
            count=len(self.selected)
            self.selected_text.configure(text=f'{count} extra'+('s' if count!=1 else '')+' selected')

    def _select_all_extras(self):
        if not self.results or not self.results.extras:
            self._info('Nothing to select','Scan folders first. The app only selects SHA-256-confirmed extra copies.')
            return
        self.selected={normalized(f.path) for f in self.results.extras}
        self._status(f'Selected {len(self.selected)} extra copies. Originals stay locked.')
        self._navigate('Exact Duplicates')

    def _clear_selection(self):
        self.selected.clear()
        self._populate();self._refresh_selected_text()

    def _auto_cleanup(self):
        self._select_all_extras()
        if self.selected:
            self._delete_selected()

    def _selected_extras(self) -> list[str]:
        if not self.results:return []
        return [f.path for f in self.results.extras if normalized(f.path) in self.selected]

    def _delete_selected(self):
        paths=self._selected_extras()
        if not paths:
            self._info('No extra copies selected','Use SELECT ALL EXTRAS or select individual extra copies. Protected originals cannot be deleted.')
            return
        count=len(paths)
        bytes_reclaimed=sum(os.path.getsize(p) for p in paths if os.path.isfile(p))
        self._confirm('Move extra copies to Recycle Bin?',
            f'{count} verified extra copies selected.\nPotential savings: {human_size(bytes_reclaimed)}.\n\nThe app will re-check the SHA-256 of EACH candidate and its protected original before moving it to the Windows Recycle Bin.\n\nFiles that changed or lost their original are SKIPPED. No permanent deletion.',
            lambda:self._do_delete(paths),action='MOVE TO RECYCLE BIN',tone='danger')

    def _do_delete(self,paths):
        if self.busy or not self.results:return
        result=self.results
        self._start_job('Recycling',lambda:recycle_extras(result,paths,stop=self.cancel_event,
            progress=lambda i,n,name:self.queue.put(('progress',('Recycling',i,n)))))

    def _review_selected(self):
        paths=self._selected_extras()
        if not paths:
            self._info('No extra copies selected','Only verified extra copies can be moved in this version.')
            return
        total=sum(os.path.getsize(p) for p in paths if os.path.isfile(p))
        self._confirm('Move to manual review?',
            f'{len(paths)} extra copies • {human_size(total)}.\n\nDestination: {self.review_root}\n\nEach file is copied, verified against SHA-256, and journaled BEFORE its original is removed. Restore is available from Manual Review.\n\nMoving files on the same drive does not free space until the review copy is removed.',
            lambda:self._do_review(paths),action='MOVE VERIFIED FILES',tone='primary')

    def _do_review(self,paths):
        if self.busy or not self.results:return
        result=self.results
        def job():
            done,errors=[],[]
            journal=ReviewJournal(self.review_root)
            for i,path in enumerate(paths,1):
                if self.cancel_event.is_set():break
                try:journal.set_aside(result,path);done.append(path)
                except Exception as e:errors.append(f'{Path(path).name}: {e}')
                self.queue.put(('progress',('Moving to review',i,len(paths))))
            return done,errors
        self._start_job('Moving to review',job)

    def _start_job(self,kind,job):
        if self.busy:return
        self.busy=True;self.cancel_event.clear();self._status(f'{kind}…')
        def run():
            try:self.queue.put(('operation_complete',(kind,job())))
            except Exception as e:self.queue.put(('error',f'{kind} failed: {e}'))
        threading.Thread(target=run,daemon=True).start()

    def _review(self):
        self._heading('Move & Organize','Review history, restore files and manage your quarantine folder.')
        panel=ctk.CTkScrollableFrame(self.content,fg_color='transparent')
        panel.grid(row=0,column=0,sticky='nsew')
        journal=ReviewJournal(self.review_root)
        make_text(panel,'Review Destination',16,LIGHT,'bold').pack(anchor='w',padx=8,pady=(5,4))
        make_text(panel,self._shorten(self.review_root,110),12,MUTED).pack(anchor='w',padx=8)
        ui_button(panel,'Choose Different Folder',self._choose_review,'secondary').pack(anchor='w',padx=8,pady=(8,15))
        entries=journal.records()
        make_text(panel,f'Restore History   •   {len(entries)} recorded moves',16,LIGHT,'bold').pack(anchor='w',padx=8,pady=12)
        if not entries:
            make_text(panel,'No review moves yet. Select extra copies under Exact Duplicates and choose Move / Review.',13,MUTED,wraplength=700,justify='left').pack(anchor='w',padx=8,pady=10)
        for entry in entries[:120]:
            row=self._row_card(panel)
            line=ctk.CTkFrame(row,fg_color='transparent');line.pack(fill='x',padx=14,pady=8)
            make_text(line,self._shorten(Path(entry.get('source','')).name,65),12,LIGHT,'bold').pack(anchor='w')
            make_text(line,entry.get('status','unknown')+' • '+human_size(entry.get('size',0))+' • '+self._shorten(entry.get('review',''),85),11,MUTED).pack(anchor='w',pady=2)
            if entry.get('status') in ('in_review','copied_pending_source_removal','original_retained'):
                ui_button(line,'RESTORE',lambda x=entry:self._restore_item(x),'primary',width=112,height=34).pack(anchor='e',pady=4)
        self._footer_note('RESTORE USES SHA-256 VERIFICATION AND NEVER OVERWRITES AN EXISTING FILE')

    def _restore_item(self,entry):
        self._confirm('Restore this file?',
            f'Restore: {Path(entry.get("source","")).name}\n\nIf a file already exists at its original path, Duplicutter uses a new RESTORED filename instead of overwriting it.',
            lambda:self._start_job('Restoring',lambda:( [ReviewJournal(self.review_root).restore(entry['id'])], [] )),
            action='RESTORE',tone='primary')

    def _details(self,item:FileItem,keeper:bool):
        role='PROTECTED KEEPER' if keeper and self.results and any(normalized(g.keeper.path)==normalized(item.path) for g in self.results.groups) else ('EXTRA COPY' if self.results and self.results.eligible(item.path) else 'READ ONLY / NOT ELIGIBLE FOR DELETION')
        text=f'Name: {item.name}\n\nFull path: {item.path}\n\nCategory: {item.category}\nSize: {human_size(item.size)} ({item.size:,} bytes)\nModified: {time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(item.mtime))}\n\nRole: {role}'
        try:
            if self.results:
                group=self.results.group_for_extra(item.path)
                if group:text+=f'\nSHA-256: {group.digest}\nProtected: {group.keeper.path}'
                else:
                    for g in self.results.groups:
                        if normalized(g.keeper.path)==normalized(item.path):text+=f'\nSHA-256: {g.digest}';break
        except Exception:pass
        self._confirm('File Details',text,lambda:self._show_folder(item.path),action='OPEN IN EXPLORER',tone='secondary',allow_cancel=True)

    def _show_folder(self,path):
        if os.name=='nt':
            try:subprocess.Popen(['explorer.exe','/select,',str(Path(path))])
            except OSError as e:self._info('Explorer unavailable',str(e))
        else:self._info('File location',path)

    def _info(self,title,message):
        self._confirm(title,message,None,action='CLOSE',tone='primary')

    def _confirm(self,title,message,callback:Callable|None,action='CONFIRM',tone='primary',allow_cancel=True):
        window=ctk.CTkToplevel(self)
        window.title(title);window.geometry('550x405' if len(message)>220 else '520x320')
        window.resizable(True,False)
        window.configure(fg_color=NAVY)
        window.transient(self)
        window.grab_set()
        window.lift()
        window.focus_force()
        make_text(window,title,20,LIGHT,'bold').pack(anchor='w',padx=22,pady=(21,8))
        scroll=ctk.CTkScrollableFrame(window,fg_color=PANEL,corner_radius=14,border_width=1,border_color=EDGE)
        scroll.pack(fill='both',expand=True,padx=20,pady=(1,12))
        make_text(scroll,message,12,MUTED,wraplength=460,justify='left').pack(anchor='w',padx=12,pady=15)
        buttons=ctk.CTkFrame(window,fg_color='transparent');buttons.pack(fill='x',padx=20,pady=(0,18))
        def done():
            window.grab_release();window.destroy()
            if callback:callback()
        if callback and allow_cancel:
            ui_button(buttons,'CANCEL',window.destroy,'secondary',width=100).pack(side='left')
        ui_button(buttons,action,done,tone,width=175).pack(side='right')

    def _drain_queue(self):
        try:
            for _ in range(80):
                op,payload=self.queue.get_nowait()
                if op=='progress':
                    name,current,total=payload
                    self._status(f'{name}: {current:,}'+(f' / {total:,}' if total else '')+' • Processing locally…')
                elif op=='scan_complete':
                    self.results=payload
                    self.selected.clear();self.busy=False
                    self._status(f'Scan complete: {len(payload.files):,} files • {len(payload.groups):,} duplicate groups • {human_size(payload.savings)} potential savings')
                    self._navigate('Exact Duplicates')
                elif op=='operation_complete':
                    kind,(done,errors)=payload
                    self.busy=False;self.selected.clear()
                    if self.results and done:
                        ids={normalized(p) for p in done}
                        self.results.files=[f for f in self.results.files if normalized(f.path) not in ids]
                        for g in self.results.groups:
                            g.extras[:]=[f for f in g.extras if normalized(f.path) not in ids]
                        self.results.groups[:]=[g for g in self.results.groups if g.extras]
                        self.results.rebuild_index()
                    self._status(f'{kind}: {len(done)} processed'+(f' • {len(errors)} errors' if errors else ''))
                    self._render()
                    self._info(kind+' finished',f'{len(done)} files processed successfully.\n\n'+('\n'.join(errors[:7]) if errors else 'Original copies remain protected.'))
                elif op=='error':
                    self.busy=False
                    self._status(payload)
                    self._info('Operation issue',payload)
        except queue.Empty:
            pass
        if self.winfo_exists():self.after(120,self._drain_queue)

    def _exit(self):
        if self.busy:
            self._confirm('Operation running','A scan or file operation is running. Cancel it and close the app? No automatic deletion occurs during scan.',self._stop_and_exit,'STOP AND EXIT','danger')
        else:
            self._save();self.destroy()

    def _stop_and_exit(self):
        self.cancel_event.set();self._save();self.destroy()


def main():
    app=Duplicutter()
    app.mainloop()

if __name__=='__main__':
    main()
