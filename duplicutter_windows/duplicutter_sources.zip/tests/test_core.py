import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core import (
    scan, validate_extra, SafetyError, recycle_extras, detect_versions, ReviewJournal,
    normalized, human_size, keeper_score, FileItem,
)

class DuplicutterSafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.home=Path(self.tmp.name)
        self.samples=self.home/'sample_files'
        self.samples.mkdir()

    def make(self, name, contents=b'same-content', folder=None):
        p=(folder or self.samples)/name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(contents)
        return str(p)

    def test_original_is_never_selected(self):
        original=self.make('Adam.pdf',b'identical')
        copy1=self.make('Adam (1).pdf',b'identical')
        copy2=self.make('Adam copy.pdf',b'identical')
        result=scan([str(self.samples)])
        self.assertEqual(len(result.groups),1)
        g=result.groups[0]
        self.assertEqual(normalized(g.keeper.path),normalized(original))
        self.assertEqual({normalized(p) for p in [copy1,copy2]}, {normalized(f.path) for f in result.extras})
        self.assertEqual(len(result.extras),2)
        self.assertFalse(result.eligible(original))
        with self.assertRaises(SafetyError):
            validate_extra(result,original)
        self.assertEqual(validate_extra(result,copy1).digest,g.digest)
        self.assertEqual(result.savings, 2*len(b'identical'))

    def test_similar_name_different_content_is_not_duplicate(self):
        a=self.make('Adam.txt',b'important')
        b=self.make('Adam (1).txt',b'different')
        result=scan([str(self.samples)])
        self.assertEqual(len(result.groups),0)
        self.assertFalse(result.eligible(a))
        self.assertFalse(result.eligible(b))

    def test_changed_candidate_blocks_deletion(self):
        original=self.make('Adam.jpg',b'a'*128)
        duplicate=self.make('Adam (1).jpg',b'a'*128)
        result=scan([str(self.samples)])
        Path(duplicate).write_bytes(b'changed')
        with patch('send2trash.send2trash') as trash:
            done, errors=recycle_extras(result,[duplicate,original])
            self.assertEqual(done,[])
            self.assertEqual(len(errors),2)
            trash.assert_not_called()

    def test_deleted_original_blocks_deletion(self):
        original=self.make('a.pdf',b'unchanged')
        duplicate=self.make('a copy.pdf',b'unchanged')
        result=scan([str(self.samples)])
        Path(original).unlink()
        with patch('send2trash.send2trash') as trash:
            done,errors=recycle_extras(result,[duplicate])
            self.assertEqual(done,[])
            self.assertTrue(errors)
            trash.assert_not_called()

    def test_recycle_only_extra_copies(self):
        original=self.make('report.xlsx',b'1'*120)
        copy=self.make('report (1).xlsx',b'1'*120)
        result=scan([str(self.samples)])
        trashed=[]
        with patch('send2trash.send2trash',side_effect=lambda path:trashed.append(path)):
            done, errors=recycle_extras(result,[original,copy])
        self.assertEqual(done,[copy]);self.assertTrue(errors)
        self.assertEqual(trashed,[copy]);self.assertTrue(Path(original).exists())

    def test_scan_multiple_roots_doesnt_double_count(self):
        sub=self.samples/'sub'
        sub.mkdir()
        self.make('a.jpg',b'abcdef',self.samples)
        self.make('a (1).jpg',b'abcdef',sub)
        result=scan([str(self.samples),str(sub)])
        self.assertEqual(len(result.files),2)
        self.assertEqual(len(result.extras),1)

    def test_versions_preserve_three_revision_groups(self):
        for i in range(1,6):
            self.make(f'Management_Report_v{i}.pdf',('pdf'+str(i)).encode())
            self.make(f'Management_Report_v{i}.docx',('docx'+str(i)).encode())
        result=scan([str(self.samples)])
        self.assertEqual(len(result.families),1)
        self.assertEqual(len(result.families[0].kept),6)
        self.assertEqual(len(result.families[0].older),4)
        self.assertEqual(len(result.groups),0)

    def test_restore_review_preserves_hash(self):
        original=self.make('Important.docx',b'file contents')
        duplicate=self.make('Important (1).docx',b'file contents')
        result=scan([str(self.samples)])
        review=self.home/'review_storage'
        journal=ReviewJournal(str(review), data_dir=str(self.home/'journal'))
        row=journal.set_aside(result,duplicate)
        self.assertFalse(Path(duplicate).exists())
        self.assertTrue(Path(row['review']).exists())
        self.assertTrue(Path(original).exists())
        restored=journal.restore(row['id'])
        self.assertTrue(Path(restored).exists())
        self.assertEqual(Path(restored).read_bytes(),b'file contents')
        self.assertFalse(Path(row['review']).exists())

    def test_cancel_read_only(self):
        self.make('a.pdf',b'a')
        cancel=threading.Event();cancel.set()
        result=scan([str(self.samples)],cancel=cancel)
        self.assertTrue((self.samples/'a.pdf').exists())
        self.assertEqual(len(result.groups),0)

if __name__=='__main__':unittest.main()
