"""Convert existing chosen icon WebP into PNG and multi-size Windows ICO."""
from pathlib import Path
from PIL import Image
root=Path(__file__).parent/'assets'
source=root/'duplicutter.webp'
if source.exists():
    im=Image.open(source).convert('RGBA')
else:
    im=Image.open(root/'duplicutter.png').convert('RGBA')
root.mkdir(exist_ok=True)
im.resize((512,512),Image.Resampling.LANCZOS).save(root/'duplicutter.png',optimize=True)
im.save(root/'duplicutter.ico',sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])
print('Icon ready:', root/'duplicutter.ico')
